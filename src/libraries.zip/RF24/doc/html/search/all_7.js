var searchData=
[
  ['isackpayloadavailable',['isAckPayloadAvailable',['../classRF24.html#a30c2736fd0df9c8128cef408c8b88e92',1,'RF24']]],
  ['ispvariant',['isPVariant',['../classRF24.html#a62846750b82682beb7593719eb60ed60',1,'RF24']]],
  ['isvalid',['isValid',['../classRF24.html#a35e5f1533b7753806c42b76e782d917e',1,'RF24']]]
];
