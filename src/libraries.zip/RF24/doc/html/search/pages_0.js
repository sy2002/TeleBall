var searchData=
[
  ['optimized_20high_20speed_20driver_20for_20nrf24l01_28_2b_29_202_2e4ghz_20wireless_20transceiver',['Optimized High Speed Driver for nRF24L01(+) 2.4GHz Wireless Transceiver',['../index.html',1,'']]],
  ['optimized_20high_20speed_20arduino_20driver_20for_20nrf24l01_202_2e4ghz_20wireless_20transceiver',['Optimized High Speed Arduino driver for nRF24L01 2.4GHz Wireless Transceiver',['../md_README.html',1,'']]]
];
