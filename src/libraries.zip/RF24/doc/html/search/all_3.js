var searchData=
[
  ['disablecrc',['disableCRC',['../classRF24.html#a5eacd9ecfbc19864801d714c292cf8be',1,'RF24']]]
];
