var searchData=
[
  ['available',['available',['../classRF24.html#a127105eb7a3b351cfe777c1cec50627a',1,'RF24::available(void)'],['../classRF24.html#ace7dd139fabc16b77cb8325faa07620f',1,'RF24::available(uint8_t *pipe_num)']]]
];
