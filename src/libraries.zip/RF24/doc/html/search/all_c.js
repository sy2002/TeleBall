var searchData=
[
  ['read',['read',['../classRF24.html#a8e2eacacfba96426c192066f04054c5b',1,'RF24']]],
  ['read_5funtil',['read_until',['../namespaceruntest.html#a91083d319078ee68f51e3763bad0ab6a',1,'runtest']]],
  ['reusetx',['reUseTX',['../classRF24.html#aeaf7fa54d3ab2a85ce215b4bf6ae933b',1,'RF24']]],
  ['rf24',['RF24',['../classRF24.html',1,'RF24'],['../classRF24.html#a8cd165a822c8f77e10782c6729c5b088',1,'RF24::RF24(uint8_t _cepin, uint8_t _cspin)'],['../classRF24.html#a41f09142485a8867f8b7ecc4f6cb3f97',1,'RF24::RF24(uint8_t _cepin, uint8_t _cspin, uint32_t spispeed)']]],
  ['runtest',['runtest',['../namespaceruntest.html',1,'']]],
  ['rxfifofull',['rxFifoFull',['../classRF24.html#ad22e44fe1a68747872fcb304a407fd30',1,'RF24']]]
];
