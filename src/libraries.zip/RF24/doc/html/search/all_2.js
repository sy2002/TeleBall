var searchData=
[
  ['closereadingpipe',['closeReadingPipe',['../classRF24.html#a9944d93994a80037e3586f340f5e0107',1,'RF24']]]
];
