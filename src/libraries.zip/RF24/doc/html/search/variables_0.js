var searchData=
[
  ['failuredetected',['failureDetected',['../classRF24.html#a2e40fe66d1231a333aa2534e8491f828',1,'RF24']]]
];
