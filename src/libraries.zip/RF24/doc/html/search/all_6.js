var searchData=
[
  ['getcrclength',['getCRCLength',['../classRF24.html#aba4ca91b829afcd94a4c11e0343e3796',1,'RF24']]],
  ['getdatarate',['getDataRate',['../classRF24.html#a72a7b11dafe8ffab6135f243decce0d7',1,'RF24']]],
  ['getdynamicpayloadsize',['getDynamicPayloadSize',['../classRF24.html#a65963ed8d8fd45f847e2f673995b85e1',1,'RF24']]],
  ['getpalevel',['getPALevel',['../classRF24.html#af7c4dcd84466168c5816382ceb366067',1,'RF24']]],
  ['getpayloadsize',['getPayloadSize',['../classRF24.html#a0aa0c7cbe3d38fef4722f3f1d2d6c5f1',1,'RF24']]]
];
